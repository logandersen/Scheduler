package Scheduler.model;
/** Customer By Division class object*/
public class CustByDiv {
    private String division;
    private int count;
    /** Constructor for the customer by division class*/
    public void CustByDiv(){
    }
    /** Get division string */
    public String getDivision() {
        return division;
    }
    /** Set division string */
    public void setDivision(String division) {
        this.division = division;
    }
    /** Get count int */
    public int getCount() {
        return count;
    }
    /** Set count int */
    public void setCount(int count) {
        this.count = count;
    }
}
